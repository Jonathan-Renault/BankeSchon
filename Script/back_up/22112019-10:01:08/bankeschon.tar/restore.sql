--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bankeschon;
--
-- Name: bankeschon; Type: DATABASE; Schema: -; Owner: yamna
--

CREATE DATABASE bankeschon WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE bankeschon OWNER TO yamna;

\connect bankeschon

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.offers (
    id integer NOT NULL,
    offer_name text NOT NULL,
    priority integer NOT NULL,
    minimum_age integer NOT NULL,
    maximum_age integer NOT NULL,
    recommanded_age text NOT NULL,
    recommanded_salary text NOT NULL,
    recommanded_pro_situation integer NOT NULL,
    rent_spend_recommanded integer NOT NULL,
    health_spend_recommanded integer NOT NULL,
    insurance_spend_recommanded integer NOT NULL,
    car_spend_recommanded integer NOT NULL,
    transport_spend_recommanded integer NOT NULL,
    communication_spend_recommanded integer NOT NULL,
    hobby_spend_recommanded integer NOT NULL,
    food_spend_recommanded integer NOT NULL,
    daily_spend_recommanded integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    recommanded_family_situation integer
);


ALTER TABLE public.offers OWNER TO yamna;

--
-- Name: all_offers; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.all_offers AS
 SELECT offers.id,
    offers.offer_name,
    offers.priority,
    offers.minimum_age,
    offers.maximum_age,
    offers.recommanded_age,
    offers.recommanded_salary,
    offers.recommanded_pro_situation,
    offers.rent_spend_recommanded,
    offers.health_spend_recommanded,
    offers.insurance_spend_recommanded,
    offers.car_spend_recommanded,
    offers.transport_spend_recommanded,
    offers.communication_spend_recommanded,
    offers.hobby_spend_recommanded,
    offers.food_spend_recommanded,
    offers.daily_spend_recommanded,
    offers.created_at,
    offers.updated_at,
    offers.recommanded_family_situation
   FROM public.offers;


ALTER TABLE public.all_offers OWNER TO yamna;

--
-- Name: history; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.history (
    id integer NOT NULL,
    accepted boolean NOT NULL,
    created_at date NOT NULL,
    id_user integer NOT NULL,
    id_offer integer NOT NULL,
    id_prospect integer NOT NULL
);


ALTER TABLE public.history OWNER TO yamna;

--
-- Name: bestseller_1; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.bestseller_1 AS
 SELECT bla.id_user,
    bla.count
   FROM ( SELECT history.id_user,
            count(history.id_offer) AS count
           FROM public.history
          WHERE ((history.accepted = true) AND (history.created_at = (date(now()) - 1)))
          GROUP BY history.id_user
          ORDER BY (count(history.id_offer)) DESC
         LIMIT 1) bla;


ALTER TABLE public.bestseller_1 OWNER TO yamna;

--
-- Name: bestseller_30; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.bestseller_30 AS
 SELECT bla.id_user,
    bla.count
   FROM ( SELECT history.id_user,
            count(history.id_offer) AS count
           FROM public.history
          WHERE ((history.accepted = true) AND (history.created_at > (date(now()) - 30)))
          GROUP BY history.id_user
          ORDER BY (count(history.id_offer)) DESC
         LIMIT 1) bla;


ALTER TABLE public.bestseller_30 OWNER TO yamna;

--
-- Name: family_situation; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.family_situation (
    id integer NOT NULL,
    label text NOT NULL,
    number integer NOT NULL
);


ALTER TABLE public.family_situation OWNER TO yamna;

--
-- Name: family_situation_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.family_situation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.family_situation_id_seq OWNER TO yamna;

--
-- Name: family_situation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.family_situation_id_seq OWNED BY public.family_situation.id;


--
-- Name: history_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.history_id_seq OWNER TO yamna;

--
-- Name: history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.history_id_seq OWNED BY public.history.id;


--
-- Name: howmanycall_1; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.howmanycall_1 AS
 SELECT count(*) AS count
   FROM ( SELECT history.id_user
           FROM public.history
          WHERE (history.created_at = (date(now()) - 1))) bla;


ALTER TABLE public.howmanycall_1 OWNER TO yamna;

--
-- Name: howmanycall_30; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.howmanycall_30 AS
 SELECT count(*) AS count
   FROM ( SELECT history.id_user
           FROM public.history
          WHERE (history.created_at > (date(now()) - 30))) bla;


ALTER TABLE public.howmanycall_30 OWNER TO yamna;

--
-- Name: prospects; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.prospects (
    id integer NOT NULL,
    is_customer integer NOT NULL,
    name text,
    surname text,
    birthday text,
    tel text,
    mail text,
    last_contact timestamp without time zone,
    can_be_contacted boolean,
    family_situation integer,
    professional_situation integer,
    salary integer,
    spendings text,
    adapted_offers text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.prospects OWNER TO yamna;

--
-- Name: howmanyprospect; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.howmanyprospect AS
 SELECT count(*) AS count
   FROM ( SELECT max(prospects.id) AS max
           FROM public.prospects
          GROUP BY prospects.id) bla;


ALTER TABLE public.howmanyprospect OWNER TO yamna;

--
-- Name: howmanyprospect_iscustomer; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.howmanyprospect_iscustomer AS
 SELECT count(*) AS count
   FROM ( SELECT max(prospects.id) AS max
           FROM public.prospects
          WHERE (prospects.is_customer = 1)
          GROUP BY prospects.id) bla;


ALTER TABLE public.howmanyprospect_iscustomer OWNER TO yamna;

--
-- Name: howmanyprospect_notiscustomer; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.howmanyprospect_notiscustomer AS
 SELECT count(*) AS count
   FROM ( SELECT max(prospects.id) AS max
           FROM public.prospects
          WHERE (prospects.is_customer = 0)
          GROUP BY prospects.id) bla;


ALTER TABLE public.howmanyprospect_notiscustomer OWNER TO yamna;

--
-- Name: mostsell_1; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.mostsell_1 AS
 SELECT bla.id_offer,
    bla.count
   FROM ( SELECT history.id_offer,
            count(history.id_offer) AS count
           FROM public.history
          WHERE ((history.accepted = true) AND (history.created_at = (date(now()) - 1)))
          GROUP BY history.id_offer
          ORDER BY (count(history.id_offer)) DESC
         LIMIT 1) bla;


ALTER TABLE public.mostsell_1 OWNER TO yamna;

--
-- Name: mostsell_30; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.mostsell_30 AS
 SELECT bla.id_offer,
    bla.count
   FROM ( SELECT history.id_offer,
            count(history.id_offer) AS count
           FROM public.history
          WHERE ((history.accepted = true) AND (history.created_at > (date(now()) - 30)))
          GROUP BY history.id_offer
          ORDER BY (count(history.id_offer)) DESC
         LIMIT 1) bla;


ALTER TABLE public.mostsell_30 OWNER TO yamna;

--
-- Name: offers_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.offers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offers_id_seq OWNER TO yamna;

--
-- Name: offers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.offers_id_seq OWNED BY public.offers.id;


--
-- Name: offers_proposed; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.offers_proposed (
    id integer NOT NULL,
    id_offer integer,
    id_prospect integer,
    id_user integer
);


ALTER TABLE public.offers_proposed OWNER TO yamna;

--
-- Name: offers_proposed_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.offers_proposed_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offers_proposed_id_seq OWNER TO yamna;

--
-- Name: offers_proposed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.offers_proposed_id_seq OWNED BY public.offers_proposed.id;


--
-- Name: professionnal_situation; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.professionnal_situation (
    id integer NOT NULL,
    label text NOT NULL,
    number integer NOT NULL
);


ALTER TABLE public.professionnal_situation OWNER TO yamna;

--
-- Name: professionnal_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.professionnal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.professionnal_id_seq OWNER TO yamna;

--
-- Name: professionnal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.professionnal_id_seq OWNED BY public.professionnal_situation.id;


--
-- Name: prospect_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.prospect_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prospect_id_seq OWNER TO yamna;

--
-- Name: prospect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.prospect_id_seq OWNED BY public.prospects.id;


--
-- Name: sellfail_1; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.sellfail_1 AS
 SELECT count(*) AS count
   FROM ( SELECT history.id_user
           FROM public.history
          WHERE ((history.created_at = (date(now()) - 1)) AND (history.accepted = false))
          GROUP BY history.id_user) bla;


ALTER TABLE public.sellfail_1 OWNER TO yamna;

--
-- Name: sellfail_30; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.sellfail_30 AS
 SELECT count(*) AS count
   FROM ( SELECT history.id_user
           FROM public.history
          WHERE ((history.created_at > (date(now()) - 30)) AND (history.accepted = false))
          GROUP BY history.id_user) bla;


ALTER TABLE public.sellfail_30 OWNER TO yamna;

--
-- Name: sellsuccess_1; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.sellsuccess_1 AS
 SELECT count(*) AS count
   FROM ( SELECT history.id_user
           FROM public.history
          WHERE ((history.created_at = (date(now()) - 1)) AND (history.accepted = true))) bla;


ALTER TABLE public.sellsuccess_1 OWNER TO yamna;

--
-- Name: sellsuccess_30; Type: VIEW; Schema: public; Owner: yamna
--

CREATE VIEW public.sellsuccess_30 AS
 SELECT count(*) AS count
   FROM ( SELECT history.id_user
           FROM public.history
          WHERE ((history.created_at > (date(now()) - 30)) AND (history.accepted = true))) bla;


ALTER TABLE public.sellsuccess_30 OWNER TO yamna;

--
-- Name: users; Type: TABLE; Schema: public; Owner: yamna
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login text NOT NULL,
    password text NOT NULL,
    role integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    token text NOT NULL
);


ALTER TABLE public.users OWNER TO yamna;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: yamna
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO yamna;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yamna
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: family_situation id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.family_situation ALTER COLUMN id SET DEFAULT nextval('public.family_situation_id_seq'::regclass);


--
-- Name: history id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.history ALTER COLUMN id SET DEFAULT nextval('public.history_id_seq'::regclass);


--
-- Name: offers id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers ALTER COLUMN id SET DEFAULT nextval('public.offers_id_seq'::regclass);


--
-- Name: offers_proposed id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers_proposed ALTER COLUMN id SET DEFAULT nextval('public.offers_proposed_id_seq'::regclass);


--
-- Name: professionnal_situation id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.professionnal_situation ALTER COLUMN id SET DEFAULT nextval('public.professionnal_id_seq'::regclass);


--
-- Name: prospects id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.prospects ALTER COLUMN id SET DEFAULT nextval('public.prospect_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: family_situation; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.family_situation (id, label, number) FROM stdin;
\.
COPY public.family_situation (id, label, number) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.history (id, accepted, created_at, id_user, id_offer, id_prospect) FROM stdin;
\.
COPY public.history (id, accepted, created_at, id_user, id_offer, id_prospect) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.offers (id, offer_name, priority, minimum_age, maximum_age, recommanded_age, recommanded_salary, recommanded_pro_situation, rent_spend_recommanded, health_spend_recommanded, insurance_spend_recommanded, car_spend_recommanded, transport_spend_recommanded, communication_spend_recommanded, hobby_spend_recommanded, food_spend_recommanded, daily_spend_recommanded, created_at, updated_at, recommanded_family_situation) FROM stdin;
\.
COPY public.offers (id, offer_name, priority, minimum_age, maximum_age, recommanded_age, recommanded_salary, recommanded_pro_situation, rent_spend_recommanded, health_spend_recommanded, insurance_spend_recommanded, car_spend_recommanded, transport_spend_recommanded, communication_spend_recommanded, hobby_spend_recommanded, food_spend_recommanded, daily_spend_recommanded, created_at, updated_at, recommanded_family_situation) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: offers_proposed; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.offers_proposed (id, id_offer, id_prospect, id_user) FROM stdin;
\.
COPY public.offers_proposed (id, id_offer, id_prospect, id_user) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: professionnal_situation; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.professionnal_situation (id, label, number) FROM stdin;
\.
COPY public.professionnal_situation (id, label, number) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: prospects; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.prospects (id, is_customer, name, surname, birthday, tel, mail, last_contact, can_be_contacted, family_situation, professional_situation, salary, spendings, adapted_offers, created_at, updated_at) FROM stdin;
\.
COPY public.prospects (id, is_customer, name, surname, birthday, tel, mail, last_contact, can_be_contacted, family_situation, professional_situation, salary, spendings, adapted_offers, created_at, updated_at) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: yamna
--

COPY public.users (id, login, password, role, created_at, updated_at, token) FROM stdin;
\.
COPY public.users (id, login, password, role, created_at, updated_at, token) FROM '$$PATH$$/3347.dat';

--
-- Name: family_situation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.family_situation_id_seq', 4, true);


--
-- Name: history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.history_id_seq', 7, true);


--
-- Name: offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.offers_id_seq', 10, true);


--
-- Name: offers_proposed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.offers_proposed_id_seq', 1, false);


--
-- Name: professionnal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.professionnal_id_seq', 6, true);


--
-- Name: prospect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.prospect_id_seq', 1001, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yamna
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: family_situation family_situation_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.family_situation
    ADD CONSTRAINT family_situation_pk PRIMARY KEY (id);


--
-- Name: history history_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pk PRIMARY KEY (id);


--
-- Name: offers offers_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pk PRIMARY KEY (id);


--
-- Name: offers_proposed offers_proposed_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers_proposed
    ADD CONSTRAINT offers_proposed_pk PRIMARY KEY (id);


--
-- Name: professionnal_situation professionnal_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.professionnal_situation
    ADD CONSTRAINT professionnal_pk PRIMARY KEY (id);


--
-- Name: prospects prospect_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.prospects
    ADD CONSTRAINT prospect_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: family_situation_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX family_situation_id_uindex ON public.family_situation USING btree (id);


--
-- Name: family_situation_number_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX family_situation_number_uindex ON public.family_situation USING btree (number);


--
-- Name: history_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX history_id_uindex ON public.history USING btree (id);


--
-- Name: offers_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX offers_id_uindex ON public.offers USING btree (id);


--
-- Name: offers_proposed_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX offers_proposed_id_uindex ON public.offers_proposed USING btree (id);


--
-- Name: professionnal_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX professionnal_id_uindex ON public.professionnal_situation USING btree (id);


--
-- Name: professionnal_situation_number_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX professionnal_situation_number_uindex ON public.professionnal_situation USING btree (number);


--
-- Name: prospect_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX prospect_id_uindex ON public.prospects USING btree (id);


--
-- Name: users_id_uindex; Type: INDEX; Schema: public; Owner: yamna
--

CREATE UNIQUE INDEX users_id_uindex ON public.users USING btree (id);


--
-- Name: offers offers_family_situation_number_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_family_situation_number_fk FOREIGN KEY (recommanded_family_situation) REFERENCES public.family_situation(number);


--
-- Name: offers offers_professionnal_situation_number_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_professionnal_situation_number_fk FOREIGN KEY (recommanded_pro_situation) REFERENCES public.professionnal_situation(number);


--
-- Name: offers_proposed offers_proposed_offers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers_proposed
    ADD CONSTRAINT offers_proposed_offers_id_fk FOREIGN KEY (id_offer) REFERENCES public.offers(id);


--
-- Name: offers_proposed offers_proposed_prospect_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers_proposed
    ADD CONSTRAINT offers_proposed_prospect_id_fk FOREIGN KEY (id_prospect) REFERENCES public.prospects(id);


--
-- Name: offers_proposed offers_proposed_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.offers_proposed
    ADD CONSTRAINT offers_proposed_users_id_fk FOREIGN KEY (id_user) REFERENCES public.users(id);


--
-- Name: prospects prospects_family_situation_number_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.prospects
    ADD CONSTRAINT prospects_family_situation_number_fk FOREIGN KEY (family_situation) REFERENCES public.family_situation(number);


--
-- Name: prospects prospects_professionnal_situation_number_fk; Type: FK CONSTRAINT; Schema: public; Owner: yamna
--

ALTER TABLE ONLY public.prospects
    ADD CONSTRAINT prospects_professionnal_situation_number_fk FOREIGN KEY (professional_situation) REFERENCES public.professionnal_situation(number);


--
-- PostgreSQL database dump complete
--

